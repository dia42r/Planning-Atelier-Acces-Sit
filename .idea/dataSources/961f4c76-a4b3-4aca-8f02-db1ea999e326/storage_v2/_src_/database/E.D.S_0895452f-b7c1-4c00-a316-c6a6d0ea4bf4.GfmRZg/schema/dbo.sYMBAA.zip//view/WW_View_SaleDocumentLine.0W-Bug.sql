CREATE VIEW dbo.WW_View_SaleDocumentLine
AS
SELECT     dbo.SaleDocumentLine.CreatedMaintenanceContractId, dbo.SaleDocumentLine.SupplierId, dbo.SaleDocumentLine.CustomerProductIds, 
                      dbo.SaleDocumentLine.EcotaxFurnitureId, dbo.SaleDocumentLine.Account, dbo.SaleDocumentLine.LinkType, dbo.SaleDocumentLine.LinkedLinesIds, 
                      dbo.SaleDocumentLine.PurchaseDeliveryAddressType, dbo.SaleDocumentLine.Duration, dbo.SaleDocumentLine.TrackingNumber, 
                      dbo.SaleDocumentLine.VolumeUnitId, dbo.SaleDocumentLine.DeliveryState, dbo.SaleDocumentLine.DeliveryDate, dbo.SaleDocumentLine.VatAmount, 
                      dbo.SaleDocumentLine.VatId, dbo.SaleDocumentLine.LimitDate, dbo.SaleDocumentLine.WeightUnitId, dbo.SaleDocumentLine.Numbering, 
                      dbo.SaleDocumentLine.DeliveredQuantity, dbo.SaleDocumentLine.Discounts0_DiscountType, dbo.SaleDocumentLine.NomenclatureCalculationType, 
                      dbo.SaleDocumentLine.BillOfQuantitiesProgram_Program, dbo.SaleDocumentLine.ReturnState, dbo.SaleDocumentLine.IncidentId, 
                      dbo.SaleDocumentLine.GuaranteeTypeId, dbo.SaleDocumentLine.MaintenanceContractId, dbo.SaleDocumentLine.VatMode, 
                      dbo.SaleDocumentLine.UnitPriceProgram_Program, dbo.SaleDocumentLine.ParentLineId, dbo.SaleDocumentLine.ItemId, dbo.SaleDocumentLine.DescriptionClear, 
                      dbo.SaleDocumentLine.Description, dbo.SaleDocumentLine.StockMovementId, dbo.SaleDocumentLine.StorehouseId, dbo.SaleDocumentLine.UnitId, 
                      dbo.SaleDocumentLine.EcotaxId, dbo.SaleDocumentLine.NetAmountVatIncludedWithDiscount, dbo.SaleDocumentLine.NetAmountVatIncluded, 
                      dbo.SaleDocumentLine.NetAmountVatExcludedWithDiscount, dbo.SaleDocumentLine.NetAmountVatExcluded, 
                      dbo.SaleDocumentLine.NetPriceVatIncludedWithDiscount, dbo.SaleDocumentLine.NetPriceVatExcludedWithDiscount, dbo.SaleDocumentLine.NetPriceVatIncluded, 
                      dbo.SaleDocumentLine.NetPriceVatExcluded, dbo.SaleDocumentLine.IsNetPriceWithFullDecimals, dbo.SaleDocumentLine.TotalDiscountRate, 
                      dbo.SaleDocumentLine.CurrencyTotalUnitDiscountAmountVatIncluded, dbo.SaleDocumentLine.UnitDiscountAmountVatExcluded, 
                      dbo.SaleDocumentLine.UnitDiscountAmountVatIncluded, dbo.SaleDocumentLine.UnitDiscountRate, dbo.SaleDocumentLine.CostPrice, 
                      dbo.SaleDocumentLine.PurchasePrice, dbo.SaleDocumentLine.IsNumberSetManually, dbo.SaleDocumentLine.RealQuantity, dbo.SaleDocumentLine.Quantity, 
                      dbo.SaleDocumentLine.IsReferencedItem, dbo.SaleDocumentLine.LineType, dbo.SaleDocumentLine.LineOrder, dbo.SaleDocumentLine.DocumentId, 
                      dbo.SaleDocumentLine.Id, dbo.SaleDocumentLine.NotIncluded, dbo.SaleDocumentLine.NetPriceVatIncludedWithParentDiscount, 
                      dbo.SaleDocumentLine.NetPriceVatExcludedWithParentDiscount, dbo.SaleDocumentLine.RealNetAmountVatIncludedWithParentDiscount, 
                      dbo.SaleDocumentLine.RealNetAmountVatExcludedWithParentDiscount, dbo.SaleDocumentLine.NetWeight, dbo.SaleDocumentLine.TotalNetWeight, 
                      dbo.SaleDocumentLine.UseComponentVat, dbo.SaleDocumentLine.NumberOfItemByPackage, dbo.SaleDocumentLine.Discounts0_UnitDiscountAmountVatIncluded, 
                      dbo.SaleDocumentLine.TotalWeight, dbo.SaleDocumentLine.Weight, dbo.SaleDocumentLine.PhaseLevel, dbo.SaleDocumentLine.OrderedQuantity, 
                      dbo.SaleDocumentLine.TotalVolume, dbo.SaleDocumentLine.Volume, dbo.SaleDocumentLine.IsPrintable, dbo.SaleDocumentLine.ManageStock, 
                      dbo.SaleDocumentLine.NomenclatureLevel, dbo.SaleDocumentLine.QuantityDecreaseByFreeQuantity, dbo.SaleDocumentLine.HasAnalyticAffectations, 
                      dbo.SaleDocumentLine.IsCustomNumberOfPackage, dbo.SaleDocumentLine.NumberOfPackage, 
                      dbo.SaleDocumentLine.UnitPriceProgram_KeepActiveFromQuoteToOrder, dbo.SaleDocumentLine.UnitPriceProgram_IsActive, 
                      dbo.SaleDocumentLine.StockBookingAllowed, dbo.SaleDocumentLine.Booked, dbo.SaleDocumentLine.DoNotCreateMovement, 
                      dbo.SaleDocumentLine.CreateMaintenanceContract, dbo.SaleDocumentLine.CreateCustomerProductInCustomerPark
FROM         dbo.SaleDocumentLine INNER JOIN
                      dbo.WW_View_SaleDocument ON dbo.SaleDocumentLine.DocumentId = dbo.WW_View_SaleDocument.Id
GO

