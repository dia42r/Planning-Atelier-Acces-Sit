CREATE VIEW dbo.WW_View_PurchaseDocument
AS
SELECT     Id AS Expr1, DocumentNumber, NumberPrefix, NumberSuffix, DocumentDate, GlobalDocumentOrder, TotalVolume, TotalWeight, TerritorialityId, VatId, 
                      DispatchedByStorehouse, InvoicingAddress_CountryIsoCode, InvoicingAddress_Npai, InvoicingAddress_City, DeliveryAddress_CountryIsoCode, 
                      DeliveryAddress_Npai, AmountVatExcludedWithDiscountAndShipping, AmountVatExcludedWithDiscountAndShippingWithoutEcotax, VatAmount, AmountVatIncluded, 
                      PreviousDepositAmount, DepositAmount, DepositCurrencyAmount, TotalDueAmount, IsEcotaxAmountIncludedToDueAmount, EcotaxAmountVatExcluded, 
                      EcotaxVatAmount, EcotaxAmountVatIncluded, UseInvoicingAddressAsDeliveryAddress, UseInvoicingContactAsDeliveryContact, 
                      DetailVatAmount0_VatAmountOnCollectionWithoutDeposit, DetailVatAmount0_VatAmountOnDebitWithoutDeposit, DetailVatAmount0_TaxAmount, 
                      DetailVatAmount0_TaxVatAmount, DetailVatAmount0_REAmount, AmountVatExcluded, CostPrice, DiscountRate, DiscountAmount, ShippingAmountVatExcluded, 
                      TotalApproachChargeToDistributeAmount, TotalApproachChargeAlreadyDistributedAmount, CurrencyTotalApproachChargeAlreadyDistributedAmount, 
                      IsVatExcludedEcotaxCalculation, IsStructuredSepaCommunication, InvoicingChargesNotSubjectToFinancialDiscount, InvoicingChargesAmountVatExcluded, 
                      LoadFabricationComponentsMode, DeliveryAddressType, xx_AchatsRecus, DetailVatAmount5_CurrencyVatAmountOnCollectionWithoutDeposit, 
                      DetailVatAmount5_CurrencyTaxAmount, DetailVatAmount5_CurrencyTaxVatAmount, DetailVatAmount5_CurrencyREAmount, RemainingAmountToDeliverVatExcluded, 
                      SendedByMail, DetailVatAmount5_CurrencyVatAmountOnDebitWithoutDeposit, KeepDepositVatAmount, DocumentLanguage, 
                      DetailVatAmount1_VatAmountOnCollectionWithoutDeposit, DetailVatAmount1_VatAmountOnDebitWithoutDeposit, DetailVatAmount1_TaxAmount, 
                      DetailVatAmount1_TaxVatAmount, DetailVatAmount1_REAmount, DetailVatAmount2_VatAmountOnCollectionWithoutDeposit, 
                      DetailVatAmount2_VatAmountOnDebitWithoutDeposit, DetailVatAmount2_TaxAmount, DetailVatAmount2_TaxVatAmount, DetailVatAmount2_REAmount, 
                      DetailVatAmount3_VatAmountOnCollectionWithoutDeposit, DetailVatAmount3_VatAmountOnDebitWithoutDeposit, DetailVatAmount3_TaxAmount, 
                      DetailVatAmount3_TaxVatAmount, DetailVatAmount3_REAmount, DetailVatAmount4_VatAmountOnCollectionWithoutDeposit, 
                      DetailVatAmount4_VatAmountOnDebitWithoutDeposit, DetailVatAmount4_TaxAmount, DetailVatAmount4_TaxVatAmount, DetailVatAmount4_REAmount, 
                      DetailVatAmount5_VatAmountOnCollectionWithoutDeposit, DetailVatAmount5_VatAmountOnDebitWithoutDeposit, DetailVatAmount5_TaxAmount, 
                      DetailVatAmount5_TaxVatAmount, DetailVatAmount5_REAmount, IsCustomNumberOfPackage, NumberOfPackage, VatMode, SerialId, SubjectToRE, REAmount, 
                      TotalNetWeight, CorrectionType, IRPFAmount, IRPFRate, AutomaticSettlementGeneration, RemainingDepositAmount, RemainingDepositCurrencyAmount, 
                      PriceWithTaxBased, RemainingAmountToDeliver, DocumentType, SupplierId, SupplierName, CloseOrderToReplenishment, CloseOrderToCountermark, 
                      ShippingNotSubjectToFinancialDiscount, DetailVatAmount0_CurrencyVatAmountOnCollectionWithoutDeposit, Notes, MaintenanceContractId, IncidentId, ReturnState, 
                      ReverseChargeMention, DeliveryStorehouseId, InvoicingChargesVatId, DeliveryCustomerId, SettlementModeId, ValidationState, DocumentState, ValidityDate, 
                      DetailVatAmount0_DetailVatId, DeliveryDate, DeliveryState, Printed
FROM         dbo.PurchaseDocument
WHERE     (DocumentDate > { fn NOW() } - 150)
GO

