CREATE VIEW dbo.WW_View_SaleDocument
AS
SELECT     DocumentNumber, Id, NumberPrefix, NumberSuffix, GlobalDocumentOrder, DispatchedByStorehouse, TotalVolume, DocumentDate, TotalWeight, TerritorialityId, VatId, 
                      InvoicingAddress_Npai, InvoicingAddress_CountryIsoCode, InvoicingAddress_City, DeliveryAddress_City, DeliveryAddress_Npai, 
                      UseInvoicingAddressAsDeliveryAddress, UseInvoicingContactAsDeliveryContact, DeliveryAddress_CountryIsoCode, CommitmentsBalanceDue, AmountVatExcluded, 
                      CostPrice, DiscountRate, DiscountAmount, AmountVatExcludedWithDiscount, ShippingVatId, AmountVatExcludedWithDiscountAndShipping, 
                      ShippingAmountVatExcluded, AmountVatExcludedWithDiscountAndShippingWithoutEcotax, VatAmountWithoutEcotax, VatAmount, AmountVatIncluded, Notes, 
                      NotesClear, TransferedDocumentId, AssociatedOrderId, AssociatedDeliveryOrderId, AssociatedInvoiceId, ModifiedSinceRecovery, RecoveredFrom, Reference, 
                      InvoicingAddress_ZipCode, InvoicingAddress_Address4, DeliveryContactId, DeliveryAddressId, InvoicingContactId, InvoicingAddressId, DeliveryAddress_ZipCode, 
                      DeliveryAddress_Address4, DeliveryAddress_Address3, DeliveryAddress_Address2, DeliveryAddress_Address1, InvoicingContact_Email, InvoicingContact_Fax, 
                      InvoicingContact_Phone, InvoicingContact_CellPhone, DeliveryContact_CellPhone, DeliveryContact_Phone, DeliveryContact_FirstName, DeliveryContact_Name, 
                      ValidityDate, DeliveryDate, DocumentState, ValidationState, SettlementModeId, OrderThirdId, OriginDocumentType, OriginDocumentNumber, IntervenerId, Priority, 
                      ColleagueId, IncidentId, ReturnState, MaintenanceContractId, DocumentType, Revision, CustomerId, HumanServiceTotalAmount, CustomerName, IRPFAmount, Printed, 
                      ReportId, PreviousDepositAmount, TotalDueAmount, IsEcotaxAmountIncludedToDueAmount, DepositAmount, DepositCurrencyAmount, 
                      PreviousDepositCurrencyAmount, VatMode
FROM         dbo.SaleDocument
WHERE     (DocumentDate > { fn NOW() } - 150)
GO

